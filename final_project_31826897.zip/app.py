
from flask import Flask, render_template, request, redirect, url_for
from pulp import *


app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
teacher_schedules = {}
schedules_by_day = {}
schedules = {}
days = []
unsatisfied_constraints = []
teacher_conflicts = {}
jsonFileResults = {}
def check_data(data, grades, teachers, time_slots, days, classroom):
    # # Perform preliminary checks for feasibility

    # # Check if there are enough classrooms and time slots to accommodate all lectures
    # total_lectures = sum(len(lectures) for grade in grades for classroom in grades[grade] for lectures in grades[grade][classroom].items())
    # total_available_slots = len(time_slots) * len(days) * sum(len(grades[grade]) for grade in grades)
    
    # if total_lectures > total_available_slots:
    #     return False, "Not enough slots and classrooms for all lectures."


    # # Check if any teacher is assigned to invalid lectures
    # for teacher, teacher_data in teachers.items():
    #     for lecture in teacher_data[1]:
    #         lecture_found = False
    #         for grade in grades:
    #             for classroom in grades[grade]:
    #                 if lecture in grades[grade][classroom]:
    #                     lecture_found = True
    #                     break
    #             if lecture_found:
    #                 break
    #         if not lecture_found:
    #             return False, f"Teacher {teacher} is not qualified for lecture {lecture}."

    # # Check if the maximum workload of each teacher can be satisfied
    # for teacher, teacher_data in teachers.items():
    #     max_workload = teacher_data[0]
    #     total_assigned_lectures = sum(len(lectures) for grade in grades for classroom, lectures in grades[grade].items() if lecture in teacher_data[1])
    #     if total_assigned_lectures > max_workload:
    #         return False, f"Teacher {teacher} has a maximum workload of {max_workload} but is assigned {total_assigned_lectures} lectures."

    # # Check for any other specific constraints as needed

    return True, "Preliminary checks passed. The problem appears feasible."



def optimize_with_pulp(classrooms, grades, teachers, time_slots, days,lectures):
     # Define the problem
    prob = LpProblem("School_Scheduling", LpMaximize)
   
    # Define the decision variables
    x = LpVariable.dicts("x", [(teacher, lecture, time_slot,day, classroom, grade) for teacher  in teachers for grade in grades for classroom in classrooms for lecture in lectures for time_slot in time_slots for day in days], cat='Binary')
    # Define the objective function here
    prob += lpSum(x) 

    for day in days:
        for time  in time_slots:
            for teacher in teachers:
                # teacher can teach only one lecture at a time
                prob += lpSum(x[(teacher, lecture, time, day, classroom, grade)] for grade in grades for classroom in classrooms for lecture in lectures) <= 1

        for teacher in teachers:
            if day in teachers[teacher][2]:
                for time in time_slots:
                    # teacher has days off 
                    prob += lpSum(x[(teacher, lecture, time, day, classroom, grade)] for grade in grades for classroom in classrooms for lecture in lectures) == 0
    
        for grade in grades:
            for classroom in classrooms:
                if classroom in grades[grade]:
                    for teacher in teachers:
                       prob += lpSum(x[(teacher, lecture, time, day, classroom, grade)] for lecture in lectures) <= 1

                    # for time in range(0, len(time_slots)-1):
                        # prob += lpSum(x[(teacher, lecture, time_slots[time], day, classroom, grade)] for teacher in teachers for lecture in lectures) - lpSum(x[(teacher, lecture, time_slots[time+1], day, classroom, grade)] for teacher in teachers for lecture in lectures) >=0
                    for teacher in teachers:
                        for lecture in lectures:
                            if lecture in grades[grade][classroom]:
                                prob += lpSum(x[(teacher, lecture, time, day, classroom, grade)] for time in time_slots) <= 1


    # for teacher in teachers:
    #     for lecture in lectures:
    #     # teacher can teach only lectures he is qualified for
    #         if lecture not in teachers[teacher][1]:
    #             prob += lpSum(x[(teacher, lecture, time, day, classroom, grade)] for time in time_slots for day in days for grade in grades for classroom in classrooms) == 0
    #         else:
    #             prob += lpSum(x[(teacher, lecture, time, day, classroom, grade)] for time in time_slots for day in days for grade in grades for classroom in classrooms) >= 1

                # for classroom in classrooms:
                #     prob += lpSum(x[(teacher, lecture, time, day, classroom, grade)] for time in time_slots for day in days for grade in grades) <=1
                #     for grade in grades:
                #         if classroom in grades[grade] and lecture in grades[grade][classroom]:
                #             prob += lpSum(x[(teacher, lecture, time, day, classroom, grade)] for time in time_slots for day in days) <=1 

    for grade in grades:
        for classroom in classrooms:
            if classroom not in grades[grade]:
                prob += lpSum(x[(teacher, lecture, time, day, classroom, grade)] for teacher in teachers for time in time_slots for day in days for lecture in lectures) == 0
            else:
                for day in days:
                    for time in range(len(time_slots)-1):
                        prob += lpSum(x[(teacher, lecture, time_slots[time], day, classroom, grade)] for teacher in teachers for lecture in lectures) - lpSum(x[(teacher, lecture, time_slots[time+1], day, classroom, grade)] for teacher in teachers for lecture in lectures) >=0
                for lecture in lectures:
                    if lecture not in grades[grade][classroom]  :
                        prob += lpSum(x[(teacher, lecture, time, day, classroom, grade)] for teacher in teachers for time in time_slots for day in days) == 0 
                    else:
                        #number of lectures in a classroom is as demanded by the school
                        prob += lpSum(x[(teacher, lecture, time, day, classroom, grade)] for teacher in teachers for time in time_slots for day in days) == grades[grade][classroom][lecture][0]
                        for teacher in teachers:
                            if teacher == grades[grade][classroom][lecture][1]:
                                prob += lpSum(x[(teacher, lecture, time, day, classroom, grade)] for time in time_slots for day in days) >= 0
                            else:
                                prob += lpSum(x[(teacher, lecture, time, day, classroom, grade)] for time in time_slots for day in days) == 0
                                
                # for teacher in teachers:
                #     for lecture in lectures:
                #         if lecture not in grades[grade][classroom] or lecture not in teachers[teacher][1]:
                #             prob += lpSum(x[(teacher, lecture, time, day, classroom, grade)] for time in time_slots for day in days) == 0
                #         else:
                #             prob += lpSum(x[(teacher, lecture, time, day, classroom, grade)] for time in time_slots for day in days) >=0 


    prob.solve(GLPK_CMD("/opt/homebrew/bin/glpsol"))


    filename = "example_problem.json"
    prob.toJson(filename)
    # Check if the problem status is optimal
    if LpStatus[prob.status] != "Optimal":
        print("The problem is not solved optimally with CBC.")
        # prob.solve(GLPK_CMD())
        # if LpStatus[prob.status] != "Optimal":
        #     print("The problem is not solved optimally.")        
        # # Iterate through the constraints and check if each one is violated
        # for constraint_name, constraint_expr in prob.constraints.items():
        #     if constraint_expr.value() > 0:
        #         # Print the associated error message for the violated constraint
        #         if constraint_name in constraint_messages:
        #             print(constraint_messages[constraint_name])
        #         else:
        #             print(f"Constraint {constraint_name} is not satisfied (Value = {constraint_expr.value()})")
        for i in unsatisfied_constraints:
            print(i)
    else:
        # The problem is optimal, and the constraints are satisfied
        print("The problem is solved optimally, and the constraints are satisfied.")

    for v in prob.variables():
        if v.varValue == 1:
            print(v.name, "=", v.varValue)

    for grade in grades:
        schedules[grade] = {}  # Use a dictionary to store schedules for each grade

        for classroom in classrooms:
            if classroom in grades[grade]:
                schedules[grade][classroom] = []  # Use a list to store schedules for each classroom

                for time_slot in time_slots:
                    entry = {'time_slot': time_slot, 'schedule': {day: '' for day in days}}

                    for day in days:
                        for teacher in teachers:
                            for lecture in lectures:


                                        if x[(teacher, lecture, time_slot, day, classroom, grade)].varValue == True:
                                            entry['schedule'][day] = f"{teacher}/{lecture}"

                    schedules[grade][classroom].append(entry)
         


    # # Iterate over teachers
    for teacher in teachers:
        teacher_schedules[teacher] = []  # Use a list to store schedules for each teacher

        for time_slot in time_slots:
            entry = {'time_slot': time_slot, 'schedule': {day: '' for day in days}}

            for day in days:
                for grade in grades:
                    for classroom in classrooms:
                        if classroom in grades[grade]:
                            for lecture in lectures:
                                if lecture in grades[grade][classroom]:
                                    if x[(teacher, lecture, time_slot, day, classroom, grade )].varValue == 1:
                                        entry['schedule'][day] = f"{lecture}/{classroom}/{grade}"

            teacher_schedules[teacher].append(entry)

    
    
    # Iterate over days
    for day in days:
        schedules_by_day[day] = []  # Use a list to store schedules for each day

        for time_slot in time_slots:
            entry = {'time_slot': time_slot, 'schedule': {}}

            for teacher in teachers:
                for grade in grades:
                    for classroom in classrooms:
                        if classroom in grades[grade]:
                            for lecture in lectures:

                                        if x[(teacher, lecture, time_slot, day, classroom, grade)].varValue == 1:
                                            entry['schedule'][f"{teacher}/{lecture}/{classroom}/{grade}"] = lecture

            schedules_by_day[day].append(entry)




def find_teacher_conflicts(schedules_by_day):
    # Create a dictionary to store merged lectures
    teacher_conflicts = {}

    # for day, day_schedule in schedules_by_day.items():
    #     for entry in day_schedule:
    #         for schedule, lecture in entry['schedule'].items():
    #             if "/" in schedule:
    #                 teacher, _, _, time_slot = schedule.split('/')
    #                 # Create a unique key based on teacher, day, and time slot
    #                 key = (teacher, day, entry['time_slot'])
    #                 # Initialize the list if it doesn't exist in the dictionary
    #                 if key not in teacher_conflicts:
    #                     teacher_conflicts[key] = []
    #                 # Append the lecture to the list
    #                 teacher_conflicts[key].append(lecture)

    # # Remove entries where the number of lectures is 1 or less
    # teacher_conflicts = {key: lectures for key, lectures in teacher_conflicts.items() if len(lectures) > 1}

    # print(teacher_conflicts)

    return teacher_conflicts


